+++
title = "{{ replace .Name "-" " " | title }}"
type = "chapter"
weight = 1
+++

This is a new chapter.