+++
categories = ["howto"]
description = "Provide your own logo and favicon"
title = "Logo"
weight = 1
+++
{{< piratify >}}