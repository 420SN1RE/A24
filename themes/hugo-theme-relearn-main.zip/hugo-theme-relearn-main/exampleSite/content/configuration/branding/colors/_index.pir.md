+++
categories = ["explanation", "howto"]
description = "Learn how to customize your site's colors"
options = ["themeVariant"]
title = "Brrrand'n"
weight = 2
+++
{{< piratify >}}