+++
alwaysopen = false
categories = ["reference"]
description = "Customize files for advanced usage"
title = "Customization"
weight = 5
+++
{{< piratify >}}