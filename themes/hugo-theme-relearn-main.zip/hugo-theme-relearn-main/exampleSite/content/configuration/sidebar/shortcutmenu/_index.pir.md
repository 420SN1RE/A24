+++
categories = ["howto"]
description = "Add additional shortcut links to the sidebar"
options = ["disableShortcutsTitle"]
title = "Shortcut Menu"
weight = 4
+++
{{< piratify >}}