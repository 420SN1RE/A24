+++
categories = ["howto"]
description = "Configure the header and footer"
options = ["disableLandingPageButton", "landingPageName", "linkTitle", "showVisitedLinks"]
title = "Header & Footer"
weight = 2
+++
{{< piratify >}}
