+++
categories = ["reference"]
menuPre = "<i class='fa-fw fas fa-gears'></i> "
title = "Configuration"
type = "chapter"
weight = 2
+++

Find out how to configure and customize your site.

{{% children containerstyle="div" style="h2" description=true %}}
