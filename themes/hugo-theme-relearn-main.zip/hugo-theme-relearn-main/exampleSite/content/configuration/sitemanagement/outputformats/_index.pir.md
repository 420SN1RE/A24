+++
categories = ["howto"]
description = "What other formats can a page be displayed in"
title = "Available Output Formats"
weight = 5
+++
{{< piratify >}}