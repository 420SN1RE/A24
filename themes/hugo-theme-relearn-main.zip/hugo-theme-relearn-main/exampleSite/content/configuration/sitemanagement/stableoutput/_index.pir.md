+++
categories = ["howto"]
description = "How to make your generated HTML output stable"
options = ["disableAssetsBusting", "disableGeneratorVersion", "disableRandomIds"]
title = "Stable Output"
weight = 6
+++
{{< piratify >}}