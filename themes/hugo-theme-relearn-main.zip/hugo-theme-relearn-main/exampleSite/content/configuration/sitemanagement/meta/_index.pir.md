+++
categories = ["howto"]
description = "What site-wide meta information can be set"
frontmatter = ["description"]
options = ["author.email", "author.name"]
title = "Meta Information"
weight = 3
+++
{{< piratify >}}