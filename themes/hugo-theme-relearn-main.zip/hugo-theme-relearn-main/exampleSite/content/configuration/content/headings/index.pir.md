+++
categories = ["howto"]
description = "Configuring heading anchors"
options = ["disableAnchorCopy", "disableAnchorScrolling"]
title = "Headings"
weight = 3
+++
{{< piratify >}}