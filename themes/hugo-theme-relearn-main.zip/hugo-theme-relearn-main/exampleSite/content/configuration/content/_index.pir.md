+++
alwaysopen = false
categories = ["reference"]
description = "Configure the content area of your site"
title = "Content"
weight = 4
+++
{{< piratify >}}