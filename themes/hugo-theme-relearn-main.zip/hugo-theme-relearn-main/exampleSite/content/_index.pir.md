+++
description = "A theme fer Cap'n Hugo designed fer documentat'n."
title = "Cap'n Hugo Relearrrn Theme"
type = "home"
[[cascade]]
	[cascade._target]
		path = "/introduction/changelog/*/*/*"
	[cascade.params]
		[cascade.params._build]
			render = "never"
+++
{{< piratify true >}}