+++
categories = ["reference"]
menuPre = "<i class='fa-fw fas fa-code-pull-request'></i> "
hidden = true
title = "Development"
type = "chapter"
weight = 5
+++
{{< piratify >}}