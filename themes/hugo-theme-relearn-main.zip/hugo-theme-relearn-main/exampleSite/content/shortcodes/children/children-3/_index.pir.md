+++
alwaysopen = false
description = "This be a demo child plank"
tags = ["children", "non-hidden"]
title = "plank 3"
weight = 30
+++
{{< piratify >}}