+++
alwaysopen = false
description = "This is a hidden demo child page"
hidden = true
tags = ["children", "the hidden"]
title = "page 4 (hidden)"
weight = 40
+++

This is a **hidden** demo child page. This page and all its children are hidden in the menu, arrow navigation and children shortcode as long as you aren't viewing this page or its children directly.
