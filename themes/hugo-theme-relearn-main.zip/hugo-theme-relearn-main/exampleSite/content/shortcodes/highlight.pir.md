+++
description = "Render code with a syntax highlighter"
title = "Highlight"
+++
{{< piratify true >}}