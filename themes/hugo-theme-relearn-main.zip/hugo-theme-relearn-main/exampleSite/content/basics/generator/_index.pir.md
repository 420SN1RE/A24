+++
categories = "theming"
title = "Stylesheet generrrat'r"
weight = 26
+++
{{< piratify >}}