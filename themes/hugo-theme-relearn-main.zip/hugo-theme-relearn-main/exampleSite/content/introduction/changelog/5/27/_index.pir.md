+++
disableToc = false
hidden = true
title = "Version 5.27"
type = "changelog"
weight = -27
+++
{{< piratify >}}
