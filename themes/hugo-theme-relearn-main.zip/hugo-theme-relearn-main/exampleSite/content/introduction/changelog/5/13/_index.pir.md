+++
disableToc = false
hidden = true
title = "Version 5.13"
type = "changelog"
weight = -13
+++
{{< piratify >}}
