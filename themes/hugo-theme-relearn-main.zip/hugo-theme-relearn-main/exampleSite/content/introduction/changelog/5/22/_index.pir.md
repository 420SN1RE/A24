+++
disableToc = false
hidden = true
title = "Version 5.22"
type = "changelog"
weight = -22
+++
{{< piratify >}}
