+++
disableToc = false
hidden = true
title = "Version 5.23"
type = "changelog"
weight = -23
+++
{{< piratify >}}
