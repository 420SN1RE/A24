+++
disableToc = false
hidden = true
title = "Version 1.2"
type = "changelog"
weight = -2
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
