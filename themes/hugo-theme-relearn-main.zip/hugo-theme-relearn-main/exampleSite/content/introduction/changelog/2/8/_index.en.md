+++
disableToc = false
hidden = true
title = "Version 2.8"
type = "changelog"
weight = -8
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
