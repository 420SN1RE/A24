+++
disableToc = false
hidden = true
title = "Version 2.3"
type = "changelog"
weight = -3
+++
{{< piratify >}}
