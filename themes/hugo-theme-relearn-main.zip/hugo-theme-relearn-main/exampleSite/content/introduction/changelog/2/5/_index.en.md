+++
disableToc = false
hidden = true
title = "Version 2.5"
type = "changelog"
weight = -5
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
