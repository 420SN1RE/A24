+++
disableToc = false
hidden = true
title = "Version 2.6"
type = "changelog"
weight = -6
+++

{{% pages showhidden="true" showdivider="true" reverse="true" %}}
