+++
disableToc = false
title = "Version 3"
type = "changelog"
weight = -3
+++

{{% pages showhidden="true" showdivider="true" %}}
