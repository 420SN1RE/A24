+++
menuPre = "<i class='fa-fw fas fa-star'></i> "
title = "Introduction"
type = "chapter"
weight = 1
+++
{{< piratify >}}