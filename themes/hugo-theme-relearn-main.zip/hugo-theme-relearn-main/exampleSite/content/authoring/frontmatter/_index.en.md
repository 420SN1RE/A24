+++
alwaysopen = false
categories = ["reference"]
description = "All things front matter"
title = "Front Matter"
weight = 2
+++

{{% children containerstyle="div" style="h2" description=true %}}
