+++
categories = ["howto"]
description = "What options are available for links and images"
frontmatter = ["externalLinkTarget", "image.errorlevel", "link.errorlevel"]
options = ["externalLinkTarget", "image.errorlevel", "link.errorlevel"]
title = "Linking"
weight = 3
+++
{{< piratify >}}