+++
alwaysopen = false
categories = ["reference"]
description = "All things front matter"
title = "Front Matter"
weight = 2
+++
{{< piratify >}}