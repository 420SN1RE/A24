+++
categories = ["reference"]
menuPre = "<i class='fa-fw fab fa-markdown'></i> "
title = "Rambl'n"
type = "chapter"
weight = 3
+++
{{< piratify >}}