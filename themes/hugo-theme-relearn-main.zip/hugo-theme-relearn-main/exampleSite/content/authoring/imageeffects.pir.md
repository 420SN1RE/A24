+++
categories = ["explanation"]
description = "How to apply graphical effects to your images"
frontmatter = ["imageEffects"]
title = "Image Effects"
weight = 5
+++
{{< piratify >}}