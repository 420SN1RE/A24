+++
categories = ["reference"]
menuPre = "<i class='fa-fw fab fa-markdown'></i> "
title = "Authoring"
type = "chapter"
weight = 3
+++

Learn how to create and organize your content pages.

{{% children containerstyle="div" style="h2" description=true %}}
