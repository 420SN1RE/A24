+++
categories = ["explanation"]
description = "Your content's directory structure"
title = "Directory Structure"
weight = 1
+++
{{< piratify >}}