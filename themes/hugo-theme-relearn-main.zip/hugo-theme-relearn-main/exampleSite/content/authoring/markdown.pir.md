+++
description = "Reference of CommonMark and Markdown extensions"
categories = ["howto", "reference"]
title = "Marrrkdown Rules"
weight = 4
+++
{{< piratify >}}